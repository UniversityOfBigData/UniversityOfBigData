#!/bin/sh
while read NAME ;do
  # コメント行除外
  echo $NAME | grep -v '^#.*' > /dev/null
  if [ $? -eq 0 ];then
    echo "$NAME"
  fi
done < ./jp.txt
