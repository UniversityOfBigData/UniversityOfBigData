#!/bin/sh
wget https://ipv4.fetus.jp/jp.txt
bash catcommentout.sh > ip_list.txt
sed -i '/^$/d' ip_list.txt
cat ip_list.txt | awk 'NR%250 != 0{printf "%s ", $1} NR%200 == 0 {printf "%s\n",$1}' | sed -e s/" "/,/g> ip_list2.txt
