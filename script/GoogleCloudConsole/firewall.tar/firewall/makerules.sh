#!/bin/sh
i=0
while read line
do
i=$(expr $i + 1)
gcloud compute firewall-rules create tcp-allow$i --action=ALLOW --rules=tcp:80,tcp:443,tcp:8000 --direction=INGRESS --priority=500 --no-enable-logging --target-tags=http-server,https-server --source-ranges=$line
done < ./ip_list2.txt
